#!/usr/bin/bash

echo "Création de la base de données dans data/sonde_info.db"
python -m data.create_db
