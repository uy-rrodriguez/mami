#!/usr/bin/python
# -*- coding: utf-8 -*-

#############################################################################
#    User :                                                                 #
#        Classe contenant l'information d'un utilisateur.                   #
#                                                                           #
#                                                                           #
#############################################################################

from arraydataobject import *


class User(ArrayDataObject):

    def __init__(self):
        super(User, self).__init__()
