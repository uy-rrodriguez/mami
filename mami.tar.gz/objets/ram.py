#!/usr/bin/python
# -*- coding: utf-8 -*-

#############################################################################
#    RAM :                                                                  #
#        Classe contenant l'information de la mémoire principale.           #
#                                                                           #
#                                                                           #
#############################################################################

from arraydataobject import *


class RAM(ArrayDataObject):

    def __init__(self):
        super(RAM, self).__init__()
