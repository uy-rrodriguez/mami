#!/usr/bin/python
# -*- coding: utf-8 -*-

#############################################################################
#    CPU :                                                                  #
#        Classe contenant l'information d'une CPU.                          #
#                                                                           #
#                                                                           #
#############################################################################

from arraydataobject import *


class CPU(ArrayDataObject):

    def __init__(self):
        super(CPU, self).__init__()
