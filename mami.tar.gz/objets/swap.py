#!/usr/bin/python
# -*- coding: utf-8 -*-

#############################################################################
#    Swap :                                                                 #
#        Classe contenant l'information de l'espace d'échange swap.         #
#                                                                           #
#                                                                           #
#############################################################################

from arraydataobject import *


class Swap(ArrayDataObject):

    def __init__(self):
        super(Swap, self).__init__()
