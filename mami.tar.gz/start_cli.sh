#!/usr/bin/bash

python -m interface.interface
